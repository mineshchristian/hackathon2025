#def main():
#    uvicorn.run("api.rt2:app",host="0.0.0.0", port=8080, reload=True)

import streamlit as st

st.markdown("4324324324")

#if __name__ == "__main__":
#    main()
