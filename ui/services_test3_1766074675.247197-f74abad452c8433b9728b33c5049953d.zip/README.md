CCIBT  Hackathon 2025

=======Team Mercurious============ 
