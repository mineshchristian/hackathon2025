"""Config package initializer."""

__all__ = ["settings"]
