
--drop  view `ccibt-hack25ww7-752.uc3_dataset.mdl_cpu_v2_nonanomaly` 

create  view `ccibt-hack25ww7-752.uc3_dataset.mdl_cpu_v3_nonanomaly` as

SELECT
t.*
FROM
ML.DETECT_ANOMALIES
(MODEL `ccibt-hack25ww7-752.uc3_dataset.mdl_cpu`
,STRUCT(0.1 AS contamination)
,
(
SELECT `uniq_id`, `failed`, `cpu_usage_distribution_avg`, `tail_cpu_usage_distribution_avg`, `resource_request_cpu_scaled`, `average_usage_cpu_scaled`, `maximum_usage_cpu_scaled` FROM `ccibt-hack25ww7-752.uc3_dataset.traces_0`
)
) as ana

join ccibt-hack25ww7-752.uc3_dataset.traces_0 t on t.uniq_id = ana.uniq_id
where 

is_anomaly = false

