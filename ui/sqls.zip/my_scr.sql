SELECT collection_id, count(1) FROM `ccibt-hack25ww7-752.uc3_dataset1.traces_1` 

group by (collection_id)
having count(1) > 1
order by count(1) asc

SELECT time_dt, start_time_2, end_time_2,  * FROM `ccibt-hack25ww7-752.uc3_dataset1.traces_1` 
where collection_id = 456094667697	



 select  * from ccibt-hack25ww7-752.uc3_dataset.mdl_mem_v2 
    where time_date >= TIMESTAMP_SUB('2025-12-16 00:44:38.923967', INTERVAL 1 MINUTE)

SELECT
*
FROM
ML.DETECT_ANOMALIES
(MODEL `ccibt-hack25ww7-752.uc3_dataset.mdl_mem_2`
,STRUCT(0.01 AS contamination)
,
(
  SELECT uniq_id, `assigned_memory_scaled`, `page_cache_memory_scaled`, `memory_accesses_per_instruction_scaled`, `resource_request_memory_scaled`, `average_usage_memory_scaled`, `maximum_usage_cpu_scaled`, `maximum_usage_memory_scaled` FROM `ccibt-hack25ww7-752.uc3_dataset.traces_0` --where time_dt = CAST('2024-01-01' AS TIMESTAMP)
)
)

where is_anomaly = true