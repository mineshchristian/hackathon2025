CREATE MODEL `ccibt-hack25ww7-752.uc3_dataset.mdl_rca_cpu_1`
OPTIONS(
  MODEL_TYPE = 'CONTRIBUTION_ANALYSIS',
  CONTRIBUTION_METRIC='SUM(maximum_usage_cpu_scaled)',
  IS_TEST_COL ='is_test',
  DIMENSION_ID_COLS =
  ['machine_id', 'scheduler','constraint_1',
  'constraint_2',
  'constraint_3',
  'constraint_4',
  'constraint_5',
  'maximum_usage_memory_scaled',
  'start_after_collection_id_1',
  'start_after_collection_id_2',
  'start_after_collection_id_3',
  'start_after_collection_id_4',
  'start_after_collection_id_5'
   

  ],

  top_k_insights_by_apriori_support = 25 -- Or use top_k_insights_by_apriori_support
) AS
SELECT
  (CASE failed
  WHEN 0 THEN false
   ELSE true END) as is_test,
  machine_id,
  CAST(scheduler as STRING) as scheduler,
  constraint_1,
  constraint_2,
  constraint_3,
  constraint_4,
  constraint_5,
  
  CAST(maximum_usage_memory_scaled as STRING) maximum_usage_memory_scaled,
  start_after_collection_id_1,
  start_after_collection_id_2,
  start_after_collection_id_3,
  start_after_collection_id_4,
  start_after_collection_id_5
  ,maximum_usage_cpu_scaled
  

FROM
  `ccibt-hack25ww7-752.uc3_dataset.traces_0` 
  where failed = 0 -- Control data set with no failure

UNION DISTINCT

SELECT
  (CASE failed
  WHEN 0 THEN false
   ELSE true END) as is_test,
  machine_id,
  CAST(scheduler as STRING) as scheduler,
  constraint_1,
  constraint_2,
  constraint_3,
  constraint_4,
  constraint_5,
  CAST(maximum_usage_memory_scaled as STRING) maximum_usage_memory_scaled,
  start_after_collection_id_1,
  start_after_collection_id_2,
  start_after_collection_id_3,
  start_after_collection_id_4,
  start_after_collection_id_5
  ,maximum_usage_cpu_scaled

FROM
  `ccibt-hack25ww7-752.uc3_dataset.traces_0` 
  where failed = 1 -- Control data set with no failure

UNION DISTINCT

SELECT  

  false as is_test,
  machine_id,
  CAST(scheduler as STRING) as scheduler,
  constraint_1,
  constraint_2,
  constraint_3,
  constraint_4,
  constraint_5,
  CAST(maximum_usage_memory_scaled as STRING) maximum_usage_memory_scaled,
  start_after_collection_id_1,
  start_after_collection_id_2,
  start_after_collection_id_3,
  start_after_collection_id_4,
  start_after_collection_id_5,
  maximum_usage_cpu_scaled
  
FROM 
`ccibt-hack25ww7-752.uc3_dataset.mdl_cpu_v2` 

UNION DISTINCT

SELECT  

  true as is_test,
  machine_id,
  CAST(scheduler as STRING) as scheduler,
  constraint_1,
  constraint_2,
  constraint_3,
  constraint_4,
  constraint_5,
  CAST(maximum_usage_memory_scaled as STRING) maximum_usage_memory_scaled,
  start_after_collection_id_1,
  start_after_collection_id_2,
  start_after_collection_id_3,
  start_after_collection_id_4,
  start_after_collection_id_5,
  maximum_usage_cpu_scaled
  
FROM 

`ccibt-hack25ww7-752.uc3_dataset.mdl_cpu_v2_nonanomaly`