CREATE MODEL `ccibt-hack25ww7-752.uc3_dataset.mdl_rca_cpu_2`
OPTIONS(
  MODEL_TYPE = 'CONTRIBUTION_ANALYSIS',
  CONTRIBUTION_METRIC='SUM(tail_cpu_usage_distribution_avg_1)',
  IS_TEST_COL ='is_test',
  DIMENSION_ID_COLS =
  ['machine_id', 'scheduler','constraint_1',
  'constraint_2',
  'constraint_3',
  'constraint_4',
  'constraint_5',
   'maximum_usage_cpu_scaled',
  'start_after_collection_id_1',
  'start_after_collection_id_2',
  'start_after_collection_id_3',
  'start_after_collection_id_4',
  'start_after_collection_id_5',
   'cluster',
   'event',
   'collection_type',
   'scheduling_class',
    'failed',
    'constraint_6',
    'constraint_7',
     'constraint_8',
     'constraint_9',
    'constraint_10',
    'cpu_usage_distribution_avg',
    'time_take',
    'page_cache_memory_scaled',
    'assigned_memory_scaled',
    'cycles_per_instruction_scaled',
    'memory_accesses_per_instruction_scaled',
    'resource_request_cpu_scaled',
    'resource_request_memory_scaled',
    'average_usage_cpu_scaled',
    'maximum_usage_memory_scaled'
    
    
  ]

  --top_k_insights_by_apriori_support = 25 -- Or use top_k_insights_by_apriori_support
) AS

SELECT  

  true as is_test,
  
  machine_id,
  CAST(scheduler as STRING) as scheduler,
  constraint_1,
  constraint_2,
  constraint_3,
  constraint_4,
  constraint_5,
  CAST(maximum_usage_memory_scaled as STRING) maximum_usage_memory_scaled,
  start_after_collection_id_1,
  start_after_collection_id_2,
  start_after_collection_id_3,
  start_after_collection_id_4,
  start_after_collection_id_5,
  --CAST(maximum_usage_cpu_scaled* ((RAND() * 1000000000)) as STRING) maximum_usage_cpu_scaled,
  CAST(maximum_usage_cpu_scaled) as STRING) maximum_usage_cpu_scaled,
    CAST(cluster as STRING)cluster ,
   CAST(event as STRING)event,
   CAST(collection_type as STRING)collection_type,
   CAST(scheduling_class as STRING)scheduling_class,
   failed ,
    CAST(constraint_6 as STRING)constraint_6,
    CAST(constraint_7 as STRING)constraint_7,
     CAST(constraint_8 as STRING)constraint_8,
     CAST(constraint_9 as STRING)constraint_9,
    CAST(constraint_10 as STRING)constraint_10,
    CAST(cpu_usage_distribution_avg as STRING)cpu_usage_distribution_avg,
    CAST(tail_cpu_usage_distribution_avg  as NUMERIC)tail_cpu_usage_distribution_avg_1,
    CAST(time_take as STRING)time_take,
    CAST(assigned_memory_scaled as STRING)assigned_memory_scaled,
    CAST(page_cache_memory_scaled as STRING)page_cache_memory_scaled,
    CAST(cycles_per_instruction_scaled as STRING)cycles_per_instruction_scaled,
    CAST(memory_accesses_per_instruction_scaled as STRING)memory_accesses_per_instruction_scaled,
    CAST(resource_request_cpu_scaled as STRING)resource_request_cpu_scaled,
    CAST(resource_request_memory_scaled as STRING)resource_request_memory_scaled,
    CAST(average_usage_cpu_scaled as STRING)average_usage_cpu_scaled
   

  
  
FROM 
`ccibt-hack25ww7-752.uc3_dataset.mdl_cpu_v3`  -- anomali data becomes test data

union all

SELECT  

  false as is_test,
  
  machine_id,
  CAST(scheduler as STRING) as scheduler,
  constraint_1,
  constraint_2,
  constraint_3,
  constraint_4,
  constraint_5,
  CAST(maximum_usage_memory_scaled as STRING) maximum_usage_memory_scaled,
  start_after_collection_id_1,
  start_after_collection_id_2,
  start_after_collection_id_3,
  start_after_collection_id_4,
  start_after_collection_id_5,
  CAST(maximum_usage_cpu_scaled* ((RAND() * 1000000000)) as STRING) maximum_usage_cpu_scaled,
    CAST(cluster as STRING)cluster ,
   CAST(event as STRING)event,
   CAST(collection_type as STRING)collection_type,
   CAST(scheduling_class as STRING)scheduling_class,
   failed ,
    CAST(constraint_6 as STRING)constraint_6,
    CAST(constraint_7 as STRING)constraint_7,
     CAST(constraint_8 as STRING)constraint_8,
     CAST(constraint_9 as STRING)constraint_9,
    CAST(constraint_10 as STRING)constraint_10,
    CAST(cpu_usage_distribution_avg as STRING)cpu_usage_distribution_avg,
    CAST(tail_cpu_usage_distribution_avg  as NUMERIC)tail_cpu_usage_distribution_avg_1,
    CAST(time_take as STRING)time_take,
    CAST(assigned_memory_scaled as STRING)assigned_memory_scaled,
    CAST(page_cache_memory_scaled as STRING)page_cache_memory_scaled,
    CAST(cycles_per_instruction_scaled as STRING)cycles_per_instruction_scaled,
    CAST(memory_accesses_per_instruction_scaled as STRING)memory_accesses_per_instruction_scaled,
    CAST(resource_request_cpu_scaled as STRING)resource_request_cpu_scaled,
    CAST(resource_request_memory_scaled as STRING)resource_request_memory_scaled,
    CAST(average_usage_cpu_scaled as STRING)average_usage_cpu_scaled
   

  
  
FROM 
`ccibt-hack25ww7-752.uc3_dataset.mdl_cpu_v2` 



UNION ALL

SELECT  

  false as is_test,
  machine_id,
  CAST(scheduler as STRING) as scheduler,
  constraint_1,
  constraint_2,
  constraint_3,
  constraint_4,
  constraint_5,
  CAST(maximum_usage_memory_scaled as STRING) maximum_usage_memory_scaled,
  start_after_collection_id_1,
  start_after_collection_id_2,
  start_after_collection_id_3,
  start_after_collection_id_4,
  start_after_collection_id_5,
  CAST(maximum_usage_cpu_scaled as STRING) maximum_usage_cpu_scaled,
  CAST(cluster as STRING)cluster ,
   CAST(event as STRING)event,
   CAST(collection_type as STRING)collection_type,
   CAST(scheduling_class as STRING)scheduling_class,
   failed ,
    CAST(constraint_6 as STRING)constraint_6,
    CAST(constraint_7 as STRING)constraint_7,
     CAST(constraint_8 as STRING)constraint_8,
     CAST(constraint_9 as STRING)constraint_9,
    CAST(constraint_10 as STRING)constraint_10,
    CAST(cpu_usage_distribution_avg as STRING)cpu_usage_distribution_avg,
    CAST(tail_cpu_usage_distribution_avg as NUMERIC)tail_cpu_usage_distribution_avg_1,
    CAST(time_take as STRING)time_take,
    CAST(assigned_memory_scaled as STRING)assigned_memory_scaled,
    CAST(page_cache_memory_scaled as STRING)page_cache_memory_scaled,
    CAST(cycles_per_instruction_scaled as STRING)cycles_per_instruction_scaled,
    CAST(memory_accesses_per_instruction_scaled as STRING)memory_accesses_per_instruction_scaled,
    CAST(resource_request_cpu_scaled as STRING)resource_request_cpu_scaled,
    CAST(resource_request_memory_scaled as STRING)resource_request_memory_scaled,
    CAST(average_usage_cpu_scaled as STRING)average_usage_cpu_scaled
  
FROM 

`ccibt-hack25ww7-752.uc3_dataset.mdl_cpu_v3_nonanomaly`
--`ccibt-hack25ww7-752.uc3_dataset.traces_0` 