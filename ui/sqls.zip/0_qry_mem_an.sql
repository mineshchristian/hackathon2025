
      CREATE MODEL `ccibt-hack25ww7-752.uc3_dataset.mdl_mem`
      OPTIONS(
        MODEL_TYPE = 'PCA',
        PCA_EXPLAINED_VARIANCE_RATIO = 0.95
      )
      AS SELECT uniq_id,`collection_id`, `assigned_memory_scaled`, `page_cache_memory_scaled`, `memory_accesses_per_instruction_scaled`, `resource_request_memory_scaled`, `average_usage_memory_scaled`, `maximum_usage_cpu_scaled`, `maximum_usage_memory_scaled` FROM `ccibt-hack25ww7-752.uc3_dataset.traces_0`
